<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/
Description: This plugin is compatible with this caregiver WordPress themes. 
Author: Mahfuz Rashid
Author URI: http://tonatheme.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'caregiver' );
include_once( 'includes/loader.php' );

//


function caregiver_bunch_widget_init2()
{
	$options = _WSH()->option();
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	
		//Widget Area
	if( class_exists( 'caregiver_RecentNews1' ) )register_widget( 'caregiver_RecentNews1' );
	if( class_exists( 'caregiver_RecentNews2' ) )register_widget( 'caregiver_RecentNews2' );
	if( class_exists( 'caregiver_AboutUs3' ) )register_widget( 'caregiver_AboutUs3' );
	if( class_exists( 'caregiver_Subscribeus' ) )register_widget( 'caregiver_Subscribeus' );
	if( class_exists( 'caregiver_Gallery' ) )register_widget( 'caregiver_Gallery' );
	if( class_exists( 'caregiver_Twitter' ) )register_widget( 'caregiver_Twitter' );
	if( class_exists( 'caregiver_Aboutus4' ) )register_widget( 'caregiver_Aboutus4' );
}
add_action( 'widgets_init', 'caregiver_bunch_widget_init2' );	